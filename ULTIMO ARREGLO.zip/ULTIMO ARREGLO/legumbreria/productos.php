<?php
include 'conexion.php';

// Guardar producto si se envió el formulario
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = $_POST['nombre'];
    $id_categoria = $_POST['id_categoria'];

    $stmt = $conn->prepare("INSERT INTO productos (nombre, id_categoria) VALUES (?, ?)");
    $stmt->bind_param("si", $nombre, $id_categoria);
    $stmt->execute();
}

// Consulta categorías para el formulario
$categorias = $conn->query("SELECT * FROM categorias");

// Consulta productos para mostrar en tabla
$sql = "SELECT p.id_producto, p.nombre, IFNULL(c.nombre_categoria, 'Sin categoría') AS categoria
        FROM productos p
        LEFT JOIN categorias c ON p.id_categoria = c.id_categoria";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Productos</title>
    <link rel="stylesheet" href="estilos.css">
</head>
<body>
    <h2>Agregar Nuevo Producto</h2>
    <form method="POST">
        Nombre: <input type="text" name="nombre" required>
        Categoría:
        <select name="id_categoria">
            <option value="">Sin categoría</option>
            <?php while($cat = $categorias->fetch_assoc()): ?>
                <option value="<?= $cat['id_categoria'] ?>"><?= $cat['nombre_categoria'] ?></option>
            <?php endwhile; ?>
        </select>
        <button type="submit">Agregar</button>
    </form>

    <h2>Lista de Productos</h2>
    <table border="1">
        <tr>
            <th>ID</th>
            <th>Nombre</th>
            <th>Categoría</th>
        </tr>
        <?php while($row = $result->fetch_assoc()): ?>
        <tr>
            <td><?= $row['id_producto'] ?></td>
            <td><?= $row['nombre'] ?></td>
            <td><?= $row['categoria'] ?></td>
        </tr>
        <?php endwhile; ?>
    </table>
</body>
</html>
