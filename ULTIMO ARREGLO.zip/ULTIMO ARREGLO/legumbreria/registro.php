<?php
include 'conexion.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = $_POST["nombre"];
    $email = $_POST["email"];
    $clave = password_hash($_POST["clave"], PASSWORD_DEFAULT);
    $rol = $_POST["rol"];

    $sql = "INSERT INTO usuario (nombre, email, clave, rol, intentos_fallidos, bloqueado)
            VALUES ('$nombre', '$email', '$clave', '$rol', 0, 0)";
    
    if ($conn->query($sql) === TRUE) {
        if ($rol === "Cliente") {
            $id_usuario = $conn->insert_id;
            $conn->query("INSERT INTO clientes (id_usuario, nombre_cliente) VALUES ($id_usuario, '$nombre')");
        }
        echo "Registro exitoso. <a href='login.php'>Iniciar sesión</a>";
    } else {
        echo "Error: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Registro</title>
    <link rel="stylesheet" href="estilos.css">
</head>
<body>
<div class="form-container">
    <h2>Registro</h2>
    <form method="POST">
        <input type="text" name="nombre" placeholder="Nombre completo" required>
        <input type="email" name="email" placeholder="Correo electrónico" required>
        <input type="password" name="clave" placeholder="Contraseña" required>
        <select name="rol" required>
            <option value="Cliente">Cliente</option>
            <option value="Vendedor">Vendedor</option>
        </select>
        <button type="submit">Registrarse</button>
        <p class="login-link">¿Ya tienes una cuenta? <a href="login.php">Inicia sesión aquí</a></p>

    </form>
</div>
</body>
</html>
