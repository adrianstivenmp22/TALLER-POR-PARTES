-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 07-04-2025 a las 21:58:07
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `legumbreria`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productos`
--

CREATE TABLE `productos` (
  `id_producto` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `categoria` varchar(50) DEFAULT NULL,
  `precio` decimal(10,2) NOT NULL,
  `stock` int(11) NOT NULL,
  `estado` enum('Bueno','Malo','Regular') NOT NULL DEFAULT 'Bueno',
  `id_proveedor` int(11) DEFAULT NULL,
  `id_categoria` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `productos`
--

INSERT INTO `productos` (`id_producto`, `nombre`, `categoria`, `precio`, `stock`, `estado`, `id_proveedor`, `id_categoria`) VALUES
(1, 'Lentejas', 'Legumbres', 5000.00, 94, 'Bueno', 1, 1),
(2, 'Frijoles', 'Legumbres', 6000.00, 80, 'Bueno', 1, 1),
(3, 'Garbanzos', 'Legumbres', 5500.00, 46, 'Regular', 2, 1),
(4, 'Arvejas', 'Legumbres', 5000.00, 57, 'Malo', 3, 1),
(5, 'Habas', 'Legumbres', 7000.00, 39, 'Bueno', 2, 3),
(6, 'Maíz', 'Cereales', 4000.00, 90, 'Regular', 4, 3),
(7, 'Quinua', 'Cereales', 12000.00, 30, 'Bueno', 3, 3),
(8, 'Chía', 'Semillas', 15000.00, 20, 'Malo', 4, 3),
(9, 'Linaza', 'Semillas', 9000.00, 50, 'Regular', 5, 3),
(10, 'Soya', 'Legumbres', 6500.00, 70, 'Bueno', 1, 3),
(11, 'sandía ', NULL, 0.00, 0, 'Bueno', NULL, 1);

--
-- Disparadores `productos`
--
DELIMITER $$
CREATE TRIGGER `auditar_cambios_stock` AFTER UPDATE ON `productos` FOR EACH ROW BEGIN
    IF OLD.stock <> NEW.stock THEN
        INSERT INTO auditoria_stock (id_producto, stock_anterior, stock_nuevo)
        VALUES (NEW.id_producto, OLD.stock, NEW.stock);
    END IF;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `auditoria_stock` AFTER UPDATE ON `productos` FOR EACH ROW BEGIN
    INSERT INTO historial_stock (producto_id, cantidad_anterior, cantidad_nueva, fecha_cambio)
    VALUES (OLD.id_producto, OLD.stock, NEW.stock, NOW());
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `evitar_eliminar_productos` BEFORE DELETE ON `productos` FOR EACH ROW BEGIN
    IF (SELECT COUNT(*) FROM detalles_pedido dp 
        JOIN pedidos p ON dp.id_pedido = p.id_pedido
        WHERE dp.id_producto = OLD.id_producto AND p.estado = 'Pendiente') > 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'No se puede eliminar un producto con pedidos pendientes';
    END IF;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `registrar_cambio_precio` BEFORE UPDATE ON `productos` FOR EACH ROW BEGIN
    IF OLD.precio <> NEW.precio THEN
        INSERT INTO historial_precios (id_producto, precio_anterior, precio_nuevo, fecha_cambio)
        VALUES (OLD.id_producto, OLD.precio, NEW.precio, NOW());
    END IF;
END
$$
DELIMITER ;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `productos`
--
ALTER TABLE `productos`
  ADD PRIMARY KEY (`id_producto`),
  ADD KEY `id_proveedor` (`id_proveedor`),
  ADD KEY `fk_categoria` (`id_categoria`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `productos`
--
ALTER TABLE `productos`
  MODIFY `id_producto` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `productos`
--
ALTER TABLE `productos`
  ADD CONSTRAINT `fk_categoria` FOREIGN KEY (`id_categoria`) REFERENCES `categorias` (`id_categoria`),
  ADD CONSTRAINT `productos_ibfk_1` FOREIGN KEY (`id_proveedor`) REFERENCES `proveedores` (`id_proveedor`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
