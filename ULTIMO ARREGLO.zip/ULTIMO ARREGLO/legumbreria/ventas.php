<?php include('conexion.php'); ?>
<!DOCTYPE html>
<html>
<head>
  <title>Ventas</title>
  <link rel="stylesheet" href="estilos.css">
</head>
<body>
  <h1>Ventas Realizadas</h1>
  <table>
    <tr>
      <th>ID</th><th>Fecha</th><th>Cliente</th><th>Total</th>
    </tr>
    <?php
    $sql = "SELECT v.id_venta, v.fecha, c.nombre_cliente, v.total
            FROM ventas v JOIN clientes c ON v.id_cliente = c.id_cliente";
    $resultado = $conexion->query($sql);
    while($row = $resultado->fetch_assoc()) {
      echo "<tr><td>{$row['id_venta']}</td><td>{$row['fecha']}</td><td>{$row['nombre_cliente']}</td><td>{$row['total']}</td></tr>";
    }
    ?>
  </table>
</body>
</html>
