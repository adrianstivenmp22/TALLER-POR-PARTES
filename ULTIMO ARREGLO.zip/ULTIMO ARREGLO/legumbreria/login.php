<?php
include 'conexion.php';
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST["email"];
    $clave = $_POST["clave"];

    $sql = "SELECT * FROM usuario WHERE email = '$email'";
    $resultado = $conn->query($sql);

    if ($resultado->num_rows == 1) {
        $usuario = $resultado->fetch_assoc();

        if ($usuario["bloqueado"]) {
            echo "Cuenta bloqueada.";
        } elseif (password_verify($clave, $usuario["clave"])) {
            $_SESSION["usuario"] = $usuario;
            $conn->query("UPDATE usuario SET intentos_fallidos = 0 WHERE id_usuario = " . $usuario["id_usuario"]);
            header("Location: principal.php");
        } else {
            $intentos = $usuario["intentos_fallidos"] + 1;
            $bloqueado = ($intentos >= 3) ? 1 : 0;
            $conn->query("UPDATE usuario SET intentos_fallidos = $intentos, bloqueado = $bloqueado WHERE id_usuario = " . $usuario["id_usuario"]);
            echo "Contraseña incorrecta. Intentos: $intentos";
        }
    } else {
        echo "Correo no encontrado.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Iniciar Sesión</title>
<link rel="stylesheet" href="estilos.css">
</head>
<body>
<div class="form-container">
    <h2>Iniciar Sesión</h2>
    <form method="POST">
        <input type="email" name="email" placeholder="Correo electrónico" required>
        <input type="password" name="clave" placeholder="Contraseña" required>
        <button type="submit">Entrar</button>
    </form>
</div>
</body>
</html>
