<?php
include 'conexion.php';
echo "¡Conexión exitosa!";
?>
